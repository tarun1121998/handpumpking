import "./App.css";
import NavRoutes from "./navigation/routing";

function App() {
  return (
    <div className="App">
      <NavRoutes />
    </div>
  );
}

export default App;
