import React from 'react'

const Panchnama = () => {
  return (
    <div>Panchnama</div>
  )
}

export default Panchnama;
