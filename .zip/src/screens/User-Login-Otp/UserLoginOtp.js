import React from 'react';

const UserLoginOtp = () => {
  return (
    <div>UserLoginOtp</div>
  )
}

export default UserLoginOtp;