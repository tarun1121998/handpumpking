import React from 'react'

const RegisterOtp = () => {
  return (
    <div>RegisterOtp</div>
  )
}

export default RegisterOtp;